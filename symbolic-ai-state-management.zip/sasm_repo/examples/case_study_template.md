# Case Study Template

A template for documenting case studies of symbolic AI experiments.
