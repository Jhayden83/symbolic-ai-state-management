# Session Log Example

This file contains an example session log demonstrating the activation of symbolic state patterns in a model.
