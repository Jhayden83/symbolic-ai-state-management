# Disclaimer

The materials in this repository are provided for research and educational purposes. The authors make no guarantees regarding the behavior of AI models triggered by these protocols. Use responsibly.
