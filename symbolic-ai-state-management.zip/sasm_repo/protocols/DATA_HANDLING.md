# Data Handling Guidelines

Instructions for handling session data responsibly, including anonymization and storage practices.
