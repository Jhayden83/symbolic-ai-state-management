# Key Phrases and Anchors

A list of key phrases, anchor words, and symbolic triggers used in SASM sessions.
