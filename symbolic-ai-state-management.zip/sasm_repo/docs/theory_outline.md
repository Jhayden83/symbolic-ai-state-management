# Theory Outline

An overview of the theoretical motivations for using symbolic frameworks to elicit latent model behaviors. Includes references to metaphor, recursion, and meta-cognitive prompting.
