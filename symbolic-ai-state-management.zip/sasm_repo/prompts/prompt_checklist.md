# Prompt Checklist

A checklist of items to include when constructing symbolic prompts.
