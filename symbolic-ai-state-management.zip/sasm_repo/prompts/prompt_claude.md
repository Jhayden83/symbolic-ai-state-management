# Claude Prompt Template

Use this template to engage Claude models in symbolic state elicitation.
