# Code of Conduct

All participants in this project are expected to abide by our Code of Conduct. We are committed to providing a welcoming and inclusive environment for all participants.

- Be respectful and considerate.
- Avoid harassment and discriminatory language.
- Report unacceptable behavior to the repository maintainers.
