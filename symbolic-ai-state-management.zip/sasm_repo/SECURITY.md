# Security Policy

If you discover a vulnerability in this repository, please report it directly to the maintainers. Do not disclose security issues publicly until they have been addressed.

- Issues related to prompt exploitation or data leakage should be handled sensitively.
